#!/bin/bash

sudo passwd -l root