#!/bin/bash

sudo apt update
sudo apt install -y dotnet-sdk-6.0
sudo apt install -y dotnet-sdk-7.0